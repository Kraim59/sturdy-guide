package com.kmusic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF101014)
private val SurfaceDark = Color(0xFF1B1B22)
private val Accent = Color(0xFFFF5A36)
private val Muted = Color(0xFFAAAAB4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KMusicApp() }
    }
}

private enum class Tab(val title: String) {
    Home("Главная"), Wave("Моя волна"), Search("Поиск"),
    Library("Коллекция"), Settings("Настройки")
}

@Composable
private fun KMusicApp() {
    var selected by remember { mutableStateOf(Tab.Home) }
    var isPlaying by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Background,
            surface = SurfaceDark,
            primary = Accent,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                Column {
                    MiniPlayer(isPlaying = isPlaying, onToggle = { isPlaying = !isPlaying })
                    NavigationBar(containerColor = Color(0xFF17171C)) {
                        val icons = listOf(
                            Icons.Default.Home, Icons.Default.GraphicEq,
                            Icons.Default.Search, Icons.Default.LibraryMusic,
                            Icons.Default.Settings
                        )
                        Tab.entries.forEachIndexed { index, tab ->
                            NavigationBarItem(
                                selected = selected == tab,
                                onClick = { selected = tab },
                                icon = { Icon(icons[index], contentDescription = tab.title) },
                                label = { Text(tab.title, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Accent,
                                    selectedTextColor = Accent,
                                    indicatorColor = Accent.copy(alpha = 0.14f),
                                    unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            AnimatedContent(
                targetState = selected,
                modifier = Modifier.padding(padding),
                label = "main-tab"
            ) { tab ->
                when (tab) {
                    Tab.Home -> HomeScreen(onWave = { selected = Tab.Wave })
                    Tab.Wave -> WaveScreen(isPlaying, onToggle = { isPlaying = !isPlaying })
                    Tab.Search -> SimpleScreen("Поиск", "Здесь появится поиск по онлайн-каталогу.")
                    Tab.Library -> SimpleScreen("Коллекция", "Любимые треки, плейлисты и история прослушиваний.")
                    Tab.Settings -> SimpleScreen("Настройки", "Настройки KMusic.")
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onWave: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Text("KMusic", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Твоя музыка. Твои правила.", color = Muted, fontSize = 14.sp)
        }
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF542A63), Color(0xFFB63D36), Color(0xFFEB7440))))
                    .clickable { onWave() }
                    .padding(22.dp)
            ) {
                Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(34.dp))
                Spacer(Modifier.height(20.dp))
                Text("ТВОЯ ПЕРСОНАЛЬНАЯ РАДИОСТАНЦИЯ", color = Color.White.copy(alpha = .8f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("Моя волна", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Музыка, которая подстраивается под тебя", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Text("ОТКРЫТЬ  →", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
        item { SectionTitle("ТВОЯ МУЗЫКА") }
        item { PlaceholderTile("Недавно прослушанное", "История появится после первых прослушиваний") }
        item { PlaceholderTile("Любимые треки", "Сохраняй музыку, которая нравится") }
        item { SectionTitle("О KMusic") }
        item {
            Text(
                "Это стартовая версия интерфейса. Онлайн-каталог, реальное воспроизведение и персональные рекомендации подключаются следующими этапами.",
                color = Muted, fontSize = 13.sp, lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun WaveScreen(isPlaying: Boolean, onToggle: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("KMUSIC WAVE", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Spacer(Modifier.height(34.dp))
        Box(
            modifier = Modifier.size(250.dp).clip(CircleShape)
                .background(Brush.sweepGradient(listOf(
                    Color(0xFFFC754B), Color(0xFF9A55D5), Color(0xFF3C9CCB),
                    Color(0xFFFC754B)
                ))),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier.size(224.dp).clip(CircleShape)
                    .background(Background),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.GraphicEq, null, tint = Accent, modifier = Modifier.size(78.dp))
            }
        }
        Spacer(Modifier.height(30.dp))
        Text("Твоя волна", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Персональные рекомендации появятся после подключения каталога", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        FilledIconButton(onClick = onToggle, modifier = Modifier.size(64.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent)) {
            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(if (isPlaying) "Демо-состояние: воспроизведение не подключено" else "Каталог ещё не подключён", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun MiniPlayer(isPlaying: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp)
            .clip(RoundedCornerShape(16.dp)).background(SurfaceDark).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(9.dp)).background(Brush.linearGradient(listOf(Accent, Color(0xFF7446A8)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null, tint = Color.White)
        }
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text("KMusic", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("Выбери музыку в каталоге", color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onToggle) {
            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
}

@Composable
private fun PlaceholderTile(title: String, subtitle: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceDark).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF30303A)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null, tint = Accent)
        }
        Column(Modifier.padding(start = 12.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SimpleScreen(title: String, description: String) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(description, color = Muted, fontSize = 14.sp)
    }
}
