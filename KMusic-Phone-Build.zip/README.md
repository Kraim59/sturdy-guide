# KMusic — Android starter

This is the first project scaffold for KMusic.

## Open
1. Extract the ZIP.
2. Open the `KMusic` folder in Android Studio.
3. Let Gradle sync finish.
4. Run the `app` configuration on an Android device or emulator.

## Current state
- Kotlin + Jetpack Compose app shell.
- Dark music-app visual direction.
- Five navigation tabs.
- Home screen and first circular Wave screen concept.
- Media3 dependencies included for the next playback stage.

Important: the current Wave play button is a UI placeholder. It does not play audio yet.
The next stage is to connect the Audius catalog, implement real ExoPlayer playback and then build the recommendation engine.

## Build
From the project directory:
- Windows: `gradlew.bat assembleDebug` (after generating/adding the Gradle wrapper in Android Studio)
- Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

## Package
`com.kmusic.app`
